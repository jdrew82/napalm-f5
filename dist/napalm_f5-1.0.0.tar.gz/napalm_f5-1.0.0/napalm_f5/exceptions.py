class CommitConfigException(Exception):
    pass


class DiscardConfigException(Exception):
    pass


class ReplaceConfigException(Exception):
    pass
